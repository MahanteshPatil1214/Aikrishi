import AppRouter from "./router/AppRouter";

export default function App() {
  //
  return (
    <>
      <div className="font-sans bg-green-50 min-h-screen">
        <AppRouter />
      </div>
    </>
  );
}
