export default function AIDiary() {
  return (
    <section className="w-screen min-h-screen overflow-hidden bg-gradient-to-br from-emerald-50 via-green-50 to-lime-100">
      <h1 className="text-center mt-20 text-2xl text-green-700">
        AI Diary Page
      </h1>
    </section>
  );
}
